// Gurbaj Singh
// 1911150
// March 10 [Created this file to clear all the field elements in the form page]

function clearItem() {
    document.getElementById("inquiryForm").reset();
}