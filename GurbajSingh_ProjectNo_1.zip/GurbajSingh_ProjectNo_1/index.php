<!--
Gurbaj Singh 
1911150
March 2 [Created the page with the header, footer and the navigation bar]
March 3 [Created loadImages to show the images in the page]
-->

<?php
define("_IMAGEARRAY_FOLDER", "Images/ImagesForArray/");
define("_IMAGE2",_IMAGEARRAY_FOLDER."vinyl_2.jpeg");
define("_IMAGE3",_IMAGEARRAY_FOLDER."vinyl_3.jpeg");
define("_IMAGE4",_IMAGEARRAY_FOLDER."vinyl_4.jpeg");
define("_IMAGE5",_IMAGEARRAY_FOLDER."vinyl_5.jpeg");

//To put all the images into array for a later shuffle and display
$imageArray = array(_IMAGE2,_IMAGE3,_IMAGE4,_IMAGE5);

//Including the Functions file
include"PHP_Functions/FunctionsFile_1.php";
createPageHeader("Homepage");
createNavbar();
loadImages($imageArray);
createPageFooter();
?>

<!-- All images used in this page are a property of Urban Outfitters
Used for educational purposes.
Link for the original art -
https://www.urbanoutfitters.com/vinyl-records -->