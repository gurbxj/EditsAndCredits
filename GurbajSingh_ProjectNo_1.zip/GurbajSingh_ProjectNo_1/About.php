<!--
Gurbaj Singh 
1911150
March 2 [Created the page with the header, footer and the navigation bar]
March 11 [Created the download link and added the logo]
-->
<?php
include"PHP_Functions/FunctionsFile_1.php";
$_GET["mode"]="about";
createPageHeader("About Us");
createNavbar();
createAboutUs();
createPageFooter();
?>