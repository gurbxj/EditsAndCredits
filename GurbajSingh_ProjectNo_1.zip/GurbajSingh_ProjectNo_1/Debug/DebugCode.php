<!-- <img id="largeImages" src="<?php echo $imageArray[0]; ?>" alt="<?php echo _DEFAULT_IMAGENOTLOAD_ERROR ?>">
$imageArray = array(_IMAGE1,_IMAGE2,_IMAGE3,_IMAGE4,_IMAGE5);
define("_IMAGE1",_IMAGEARRAY_FOLDER."vinyl_1.jpeg");


or substr(($_POST[$fieldName]),0,1)!=_PRODUCT_FIRST_CHARACTER_UPPER

//Validating if all the fields were filled
                    // if($var_ProductID==null or $var_FirstName==null or $var_LastName==null 
                    // or $var_City==null or $var_Comments==null or $var_Price==null or $var_Quantity==null)


                    if(isset($_POST["refresh"]))
{
    ?>
    <script>
        document.getElementsByClassName("formFields").innerHTML="";
    </script>
    //<?php
} -->

echo 20/0;
throw new Exception('Uncaught Exception occurred');