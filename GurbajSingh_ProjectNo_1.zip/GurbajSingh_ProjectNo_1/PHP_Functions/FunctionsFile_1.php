<!-- 
Gurbaj Singh
1911150
March 2 [Created Header,Footer and Navbar functions]
March 3 [Created loadImages and showError functions]
March 5 [Created manageError and manageException functions]
March 8 [Created all the validation functions]
March 10[Created createForm and createPurchasesPage]
-->

<?php
//The constants
//Constants for folders and files
define("_FOLDER_CSS","CSS/");
define("_FILE_CSS_DEFAULT",_FOLDER_CSS."def_stylesheet.css");
define("_FILE_CSS_PURCHASE",_FOLDER_CSS."purchase_stylesheet.css");
define("_FILE_CSS_FORM",_FOLDER_CSS."form_stylesheet.css");
define("_FILE_CSS_ABOUT",_FOLDER_CSS."about_stylesheet.css");
define("_FILE_CSS_NAVBAR",_FOLDER_CSS."navbar_stylesheet.css");
define("_FILE_CSS_COMMAND",_FOLDER_CSS."command_stylesheet.css");
define("_FONT_LINK","https://fonts.googleapis.com/css?family=Inter&display=swap");
define("_IMAGE_FOLDER", "Images/");
define("_LOGO",_IMAGE_FOLDER."logo.png");
define("_JS_FOLDER","Javascript/");
define("_JS_FILE",_JS_FOLDER."script.js");
define("_IMAGEARRAY1_FOLDER", _IMAGE_FOLDER."ImagesForArray/");
define("_IMAGE1",_IMAGEARRAY1_FOLDER."vinyl_1.jpeg");
define("_DEBUG_FOLDER","Debug/");
define("_LOG_FILE",_DEBUG_FOLDER."logs.txt");
define("_CHEATSHEET_FILE","CheatsheetPHP.php");

//Constants for redirecting users to the NewEgg Website
define("_IMAGE_REDIRECT","https://www.newegg.ca/");

//Constant for error for image not loading
define("_DEFAULT_IMAGENOTLOAD_ERROR","This image did not load properly.");

//Constants for pages in the website
define("_HOME_PAGE","./index.php");
define("_FORM_PAGE","./form.php");
define("_PURCHASES_PAGE","./purchases.php");
define("_ABOUTUS_PAGE","./About.php");

// Constants used for validations
define("_CLASS_OF_ERROR","errorMessages");
define("_POST_VALUE","submit");
define("_PRODUCT_FIRST_CHARACTER_LOWER","p");
define("_PRODUCT_FIRST_CHARACTER_UPPER","P");
define("_KEY_MAX_LENGTH",12);
define("_CITY_MAX_LENGTH",8);
define("_COMMENT_MAX_LENGTH",200);
define("_NAME_MAX_LENGTH",20);
define("_MAX_PRICE",10000);
define("_MIN_PRICE",1);
define("_MAX_QUANTITY",99);
define("_MIN_QUANTITY",1);  

//Constant for current tax rates in decimals
define("_CURRENT_TAX_RATE",.1205);

//Constant for the End of Line
define("_FILE_EOL","\r\n");
?>

<!-- Javascript code file -->
<script src="<?php echo _JS_FILE; ?>" type="text/javascript"></script>
<?php
// Validation flag used to validate succesful number of validations during the write operation in purchases.txt
$_GET["validationFlags"]=0;

// Creating page header that takes title as a parameter.
function createPageHeader($title)
{
    ?>
    <!DOCTYPE html>
    <?php
    header('Content-Type: text/html; Charset="UTF-8"');
    // Sets a user-defined error handler function
    set_error_handler("manageError");
    // Sets a user-defined exception handler function
    set_exception_handler("manageException");
    ?>
    <html lang="en" xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <meta charset='UTF-8'>
    <?php
    // Sets the stylesheet file to the default for the index page.
    $stylesheetFile = _FILE_CSS_DEFAULT;
    if(isset($_GET["mode"]))
    {
        if($_GET["mode"]=="purchase")
        {
            // Sets the $stylesheet file to the stylesheet for the purchases page
            $stylesheetFile = _FILE_CSS_PURCHASE;
            if(isset($_GET["command"]))
            {
                //To convert the background to white
                if($_GET["command"]=="print")
                {
                    $stylesheet=_FILE_CSS_COMMAND;
                }
            }
        }
        if($_GET["mode"]=="form")
        {
            // Sets the $stylesheet file to the stylesheet for the form page
            $stylesheetFile = _FILE_CSS_FORM;
        }
        if($_GET["mode"]=="about")
        {
            // Sets the $stylesheet file to the stylesheet for the about us page
            $stylesheetFile = _FILE_CSS_ABOUT;
        }
    }
    ?>
    <!-- Navbar is used in all the pages so we use this stylesheet in all the pages -->
    <link rel="stylesheet", type="text/css", href="<?php echo _FILE_CSS_NAVBAR; ?>">
    <!-- Sets the stylesheet as for any page -->
    <link rel="stylesheet", type="text/css", href="<?php echo $stylesheetFile; ?>">
    <!-- To set the font of the page -->
    <link href="<?php echo _FONT_LINK; ?>" rel="stylesheet">
    <!-- To set the title of the page -->
    <title><?php echo $title ?></title>
    <!-- To set the icon of the page -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo _LOGO; ?>"/>
    </head>
    <body>
<?php
}
//Function to create the Navigation Bar
function createNavbar()
{
?>
    <nav id="page-nav">
        <!-- The hamburger menu -->
        <label for="hamburger">&#9776;</label>
        <!-- &#9776 is the code for hamburger icon -->
        <input type="checkbox" id="hamburger"/>
        <ul id="navbar_ul">
            <li id="logo_img"><img  width="47"  src="<?php echo _LOGO; ?>"/></li>
            <li><a href="<?php echo _HOME_PAGE; ?>">Home</a></li>
            <li><a href="<?php echo _FORM_PAGE; ?>">Form</a></li>
            <li><a href="<?php echo _PURCHASES_PAGE; ?>">Purchase</a></li>
            <li><a href="<?php echo _ABOUTUS_PAGE;?>">About Us</a></li>
        </ul>   
    </nav>
<?php
}
//Function to create the default footer for all the pages
function createPageFooter()
{
    //Sets the datetime to the current time.
    $date = new datetime("now");
    ?>
    <br>
    <footer id="copyrightInfo">
        <p>
            Gurbaj Singh &copy;
            <?php echo date("Y") ?>
        </p>
    </footer>
    </body>
    </html>
    <?php
}
function loadImages($imageArray)
{
    //Shuffles the smaller four images to be shown in the index page.
    shuffle($imageArray);
    ?>
    <!-- Display the bigger image(the 100% bigger image) -->
    <div id="largeImageDiv">
        <a href="<?php echo _IMAGE_REDIRECT ?>">
            <img id="largeImages" src="<?php echo _IMAGE1; ?>" alt="<?php echo _DEFAULT_IMAGENOTLOAD_ERROR ?>">
        </a>
    </div>
    <?php
    // Displays the smaller images
    for($index=0;$index<count($imageArray);$index++)
    {
        ?>
        <div id="smallImageDiv">
            <div id="smallImages">
                <a href="<?php echo _IMAGE_REDIRECT ?>">
                    <img src="<?php echo $imageArray[$index]; ?>" alt="<?php echo _DEFAULT_IMAGENOTLOAD_ERROR ?>" style="width:100%">
                </a>
            </div>
        </div>
    <?php
    }   
}

//The function that would override the default error handler in the webpage
function manageError($errorCode, $errorMessage, $errorFile, $errorLine)
{
    $browserName = $_SERVER['HTTP_USER_AGENT'];
    $currentTime = new DateTime("now");
    $errorOccurence = "An error occured at " . $currentTime->format("Y/M/d H:i:s")."\r\n".
    "Error Code: ".$errorCode."\r\n"."Error Message: ".$errorMessage."\r\n". 
    "Error File: ".$errorFile."\r\n"."Error Line: ".$errorLine."\r\n".
    "Browser: ".$browserName."\r\n";
    file_put_contents(_LOG_FILE, $errorOccurence, FILE_APPEND);
    error_log($errorOccurence);
    
    die("An Error occured.");
}

//The function that would override the default exception handler in the webpage
function manageException($exception)
{
    $browserName = $_SERVER['HTTP_USER_AGENT'];
    $currentTime = new DateTime("now");
    $exceptionOccurence = "An exception occured at " . $currentTime->format("Y/M/d H:i:s")."\r\n".
    "Exception code: ".$exception->getCode()."\r\n"."Exception message: ".$exception->getCode()."\r\n".
    "Exception Message: ".$exception->getMessage()."\r\n"."FileName: ".$exception->getFile(). "\r\n".
    "Line :".$exception->getLine()."\r\n"."Browser: ".$browserName."\r\n";
    file_put_contents(_LOG_FILE, $exceptionOccurence, FILE_APPEND);
    error_log($exceptionOccurence);
    die("An exception occured.");
}

//Function to show the errors
function showError($errorMessage)
{
    ?>
    <label class="<?php echo _CLASS_OF_ERROR ?>">
        <?php echo $errorMessage; ?>
    </label>
    <?php
}

//Function to validate the product key
function validateKey($fieldName)
{
    if(isset($_POST[_POST_VALUE]))
    {
        if($_POST[$fieldName]=="")
        {
            showError($fieldName." can not be empty.");
        }
        else
        {
            if(mb_substr(ucfirst(($_POST[$fieldName])),0,1)!=_PRODUCT_FIRST_CHARACTER_UPPER )
            {
                showError($fieldName." can only start with p or P.");
            }
            elseif(is_numeric( $_POST[$fieldName]))
            {
                showError("Please enter text values only.");
            }
            elseif(mb_strlen ( $_POST[$fieldName])>_KEY_MAX_LENGTH)
            {
                showError($fieldName." can not be longer than "._KEY_MAX_LENGTH." characters."); 
            }
            else
            {
                //Increasing the validation flag number to allow the validation for purchases page
                $_GET["validationFlags"]++;
            }
        }
    }
}

//Function to validate the first and last name and also the city name.
function validateStrings($fieldName,$maxLength)
{
    if(isset($_POST[_POST_VALUE]))
    {
        if(is_numeric($_POST[$fieldName]))
        {
            showError($fieldName." can not contain numeric values.");
        }
        else
        {
            if($_POST[$fieldName]=="")
            {
                showError($fieldName." can not be empty.");
            }
            //Using multibyte to allow the proper working of the accented characters
            elseif (mb_strlen($_POST[$fieldName])>$maxLength) {
                showError($fieldName." can not be more than ".$maxLength." characters.");
            }
            else
            {
                //Increasing the validation flag number to allow the validation for purchases page
                $_GET["validationFlags"]++;
            }
        }
    }
}

//Function to validate the comment left on the form page.
function validateComments($fieldName,$maxLength)
{
    if(isset($_POST[_POST_VALUE]))
    {
        if(is_numeric($_POST[$fieldName]))
        {
            showError($fieldName." can not contain numeric values.");
        }
        else
        {
            //Using multibyte to allow the proper working of the accented characters
            if (mb_strlen($_POST[$fieldName])>$maxLength) {
                showError($fieldName." can not be more than ".$maxLength." characters.");
            }
            else
            {
                //Increasing the validation flag number to allow the validation for purchases page
                $_GET["validationFlags"]++;
            }
        }
    }
}

//Function to validate the price entered in the form.
function validatePrice($fieldName,$maxPrice,$minPrice)
{
    if(isset($_POST[_POST_VALUE]))
    {
        if(!is_numeric($_POST[$fieldName]))
        {
            showError($fieldName." should be a numeric value.");
        }
        else
        {
            if($_POST[$fieldName]>$maxPrice)
            {
                showError("The ".$fieldName." cannot be more than ".$maxPrice);
            }
            elseif($_POST[$fieldName]<$minPrice) 
            {
                showError("The ".$fieldName." cannot be less than ".$minPrice);
            }
            else
            {
                //Increasing the validation flag number to allow the validation for purchases page
                $_GET["validationFlags"]++;
            }
        }
    }
}

//Function to validate the quantity entered in the form.
function validateQuantity($fieldName,$maxQuantity,$minQuantity)
{
    if(isset($_POST[_POST_VALUE]))
    {
        if(is_float($_POST[$fieldName]))
        {
            showError($fieldName." can only be a positive integer value.");
        }
        else
        {
            if($_POST[$fieldName]=="")
            {
                showError($fieldName." can not be empty.");
            }
            else
            {
                if($_POST[$fieldName]>$maxQuantity)
                {
                    showError($fieldName." can not be more than ".$maxQuantity);
                }
                elseif($_POST[$fieldName]<$minQuantity) 
                {
                     showError($fieldName." can not be less than ".$minQuantity);
                }
                else
                {
                    //Increasing the validation flag number to allow the validation for purchases page
                    $_GET["validationFlags"]++;
                }
            }
        }
    }
}

//Function to create a form in the form.php page
function createForm()
{
    ?>
    <div id="contentdiv">
        <p>
            Great shopping experience guaranteed!
        </p>
        <div class="formBox">
            <form action="form.php" id="inquiryForm" method="POST">
                <div class="row">
                    <label for="ProductID">Product ID</label>
                    <input class="formFields" type="text" id="ProductID" name="ProductID" placeholder="Product ID">
                    <label class="errorMessages">
                        <!-- For validation -->
                        <?php validateKey("ProductID")?>
                    </label>
                </div>
                <div class="row">
                    <label for="FirstName">First Name</label>
                    <input class="formFields" type="text" id="FirstName" name="FirstName" placeholder="First Name">
                    <label class="errorMessages">
                        <!-- For validation -->
                        <?php validateStrings("FirstName",_NAME_MAX_LENGTH)?>
                    </label>
                </div>
                <div class="row">
                    <label for="LastName">Last Name</label>
                    <input class="formFields" type="text" id="LastName" name="LastName" placeholder="Last Name">
                    <label class="errorMessages">
                        <!-- For validation -->
                        <?php validateStrings("LastName",_NAME_MAX_LENGTH)?>
                    </label>
                </div>
                <div class="row">
                    <label for="CityName">City</label>
                    <input class="formFields" type="text" id="CityName" name="CityName" placeholder="City">
                    <label class="errorMessages">
                        <!-- For validation -->
                        <?php validateStrings("CityName",_CITY_MAX_LENGTH)?>
                    </label>
                </div>
                <div class="row">
                    <label for="Comments">Comments</label>
                    <input class="formFields" type="text" id="Comments" name="Comments" placeholder="Comments">
                    <label class="errorMessages">
                        <!-- For validation -->
                        <?php validateComments("Comments",_COMMENT_MAX_LENGTH)?>
                    </label>
                </div>
                <div class="row">
                    <label for="Price">Price</label>
                    <input class="formFields" type="float" id="Price" name="Price" placeholder="Price">
                    <label id="errorMessages">
                        <!-- For validation -->
                        <?php validatePrice("Price",_MAX_PRICE,_MIN_PRICE)?>
                    </label>
                </div>
                <div class="row">
                    <label for="Quantity">Quantity</label>
                    <input class="formFields" type="number" id="Quantity" name="Quantity" min="<?php echo _MIN_QUANTITY; ?>" max="<?php echo _MAX_PRICE; ?>"
                     placeholder="Quantity">
                     <label id="errorMessages">
                        <!-- For validation -->
                        <?php validateQuantity("Quantity",_MAX_QUANTITY,_MIN_QUANTITY)?>
                    </label>
                </div>
                <div class="row">
                    <!-- For submitting the data of the form -->
                    <input type="submit" name="submit" value="Submit">
                    <!-- To empty the contents of all the form fields -->
                    <button id="btn_refresh" type="button" name="refresh" value="Refresh" onclick="clearItem()">
                        Refresh
                    </button>
                </div>
                <?php
                if(isset($_POST[_POST_VALUE]))
                {
                    //Setting variables as the inputted values.
                    $var_ProductID=$_POST["ProductID"];
                    $var_FirstName=$_POST["FirstName"];
                    $var_LastName=$_POST["LastName"];
                    $var_City=$_POST["CityName"];
                    $var_Comments=$_POST["Comments"];
                    $var_Price=round($_POST["Price"],2);
                    $var_Quantity=$_POST["Quantity"];
                    
                    if($_GET["validationFlags"]!=7)
                    {
                        echo"Please fill all the fields before continuing.";
                    }
                    //If all the fields are filled.
                    else
                    {
                        //Calculating the applicable taxes
                        $var_SubTotal = round($var_Quantity*$var_Price,2);
                        $var_Taxes = round(($var_SubTotal*_CURRENT_TAX_RATE),2);
                        //Calculating the total price of the items with the tax
                        $var_Total = round(($var_SubTotal+$var_Taxes),2);
                        //Inserting all the data into an array
                        $array_Purchases = array($var_ProductID,$var_FirstName,$var_LastName,$var_City,
                        $var_Comments,$var_Price,$var_Quantity,$var_SubTotal,$var_Taxes,$var_Total);
                        //Converting the computed array into a string for the purchases text file
                        $string_Purchases = json_encode($array_Purchases);
                        //Creating and appending the string into a text file
                        $append_TextFile = fopen("purchases.txt","a");
                        file_put_contents("purchases.txt",$string_Purchases._FILE_EOL,FILE_APPEND);
                        fclose($append_TextFile);
                    }
                }
                ?>
            </form>
        </div>
    </div>
    <?php
}

//Functions to create the purchases section of the purchases.php page
function createPurchasesPage()
{
    ?>
    <h1>Purchased Products</h1>
    <?php
    //Opening the file to read the data from
    $fileToOpen = fopen("purchases.txt", "r") or die("Not able to open file.");
    ?>
        <table class="purchasedProductsTable">
            <tr id="purchasedHeadings">
                <th><h2>Product ID</h2></th>
                <th><h2>First Name</h2></th>
                <th><h2>Last Name</h2></th>
                <th><h2>City</h2></th>
                <th><h2>Comments</h2></th>
                <th><h2>Price</h2></th>
                <th><h2>Quantity</h2></th>
                <th><h2>SubTotal</h2></th>
                <th><h2>Taxes</h2></th>
                <th><h2>Grand Total</h2></th>
            </tr>
            <?php
            $fileName = "purchases.txt";
            $fileContents = file($fileName);

            foreach($fileContents as $eachLine)
            {
                $arrayContents = json_decode($eachLine);
                //To check if their is any data in the file
                if($arrayContents != null)
                {
                    ?>
                    <tr>
                        <?php
                        foreach($arrayContents as $eachContent)
                        {
                        ?>
                        <th>
                            <?php echo $eachContent;?>
                        </th>
                        <?php
                        }
                        ?>
                    </tr>
                    <?php
                }
            }
        ?>
    </table>
    <div id="mainDiv">
        </br>
        <button>
            <a href="<?php echo _CHEATSHEET_FILE;?>" download>
            Download Cheatsheet!
            </a>
        </button>
    </div>
    <?php            
}
function createAboutUs()
{
    ?>
    <div id="mainDiv">
        <img src="<?php echo _LOGO; ?>" alt="This is an image of the logo">
        </br>
        <button>
            <a href="<?php echo _CHEATSHEET_FILE;?>" download>
            Download Cheatsheet!
            </a>
        </button>
    </div>
    <?php
}
?>

<!-- Logo created from the website
https://www.canva.com -->

<!-- Photo used in the background of the form page is credited to
Miguel Á. Padriñán from Pexels -->