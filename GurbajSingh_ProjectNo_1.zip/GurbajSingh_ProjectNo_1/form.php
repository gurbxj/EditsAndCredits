<!-- Gurbaj Singh 
1911150
March 2 [Created the page with the header, footer and the navigation bar]
March 8 [Created all the validation functions for this form]
March 10[Created the createForm function for this page]
-->
<script src="script.js" type="text/javascript"></script>
<?php
include"PHP_Functions/FunctionsFile_1.php";
$_GET["mode"]="form";
createPageHeader("Form");
createNavbar();
createForm();
createPageFooter();
?>