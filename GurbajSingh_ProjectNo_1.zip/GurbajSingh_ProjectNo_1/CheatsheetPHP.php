#Cheatsheet of php
#Gurbaj Singh Bajwa 1911150
<?php
//=================================================================================================================================
//Start and End tags
// <?php and ? >

//=================================================================================================================================

//To print something on the screen
echo"quelquechose";

//=================================================================================================================================
//Setting constants in PHP
//Using these, we can set relative paths that can be used as the project is run in other devices
define("_FOLDER_CSS","CSS/");
define("_FILE_CSS_DEFAULT",_FOLDER_CSS."stylesheet.css");
//We should set such constants at the top in PHP and always dynamic fields like this, so that we can easily change our website
//These constants were used to set the stylesheet of a page, as follows-
<link rel="stylesheet", type="text/css", href="<?php echo _DEFAULT_STYLESHEET; ?>">;

//===================================================================================================================================
//To find the position of an element in a string
$string = "nike";
strpos($string,'k');

//===================================================================================================================================
//To replace a particular part of the string
$replaceResult = str_replace($search,$replace,$subject);

//===================================================================================================================================
//substr — Return part of a string
substr ( string $string , int $start [, int $length ] ) : string
//Returns the portion of string specified by the start and length parameters
/*
If start is non-negative, the returned string will start at the start'th position in string, counting from zero.
For instance, in the string 'abcdef', the character at position 0 is 'a', the character at position 2 is 'c', and so forth.
If start is negative, the returned string will start at the start'th character from the end of string.
*/

//===================================================================================================================================
//To check the value of a variable is set
isset($var)

//===================================================================================================================================
//$_GET
//An associative array of variables passed to the current script via the URL parameters (aka. query string).
//Note that the array is not only populated for GET requests, but rather for all requests with a query string. 
//
if(isset($_GET["firstname"]))
{
    echo" The first name is ".$_GET["firstname"];
}

if(isset($_GET["lastname"]))
{
    echo" The lastname is ".$_GET["lastname"];
}
//In this case, according to the value of firstname and lastname set in the URL, we receive different results
//To set the value of mode->
http://localhost:8088/PHP_ProjectFunctions/index.php?firstname=gurbaj,lastname=bajwa

//So we get the result 
//firstname=gurbaj,lastname=bajwa printed on the screen.

//===================================================================================================================================
//ord — Convert the first byte of a string to a value between 0 and 255
$string = "LaSalle Collège";
echo chr(195).chr(169);
for($position = 0; $position < strlen($string); $position++){
    echo "<br>".$string[$position]."=".ord($string[$position]);
} //Returns-
// é
// L=76
// a=97
// S=83
// a=97
// l=108
// l=108
// e=101
//  =32
// C=67
// o=111
// l=108
// l=108
// �=195
// �=168
// g=103
// e=101 


//===================================================================================================================================
//Datetime in php
//These functions allow you to get the date and time from the server where your PHP scripts are running.
//We can use these functions to format the date and time in many different ways. 
$date = new datetime("now"); //Sets the value of the variable date to the current date and time

//===================================================================================================================================
//The datetime could also be used to analyze the performance in an website by checking how much time it takes to go through a function
//or a particular tag
<?php
$startTime = new DateTime("now");
for($index = 1; $index <= 100000; $index++)
{
    file_put_contents("test.txt","abc/r/n");
}
$endTime = new DateTime("now");
$dateInterval = $startTime->diff($endTime);
echo"It took ".$dateInterval->format("%s.%F")." seconds to execute.";
?>

//===================================================================================================================================
//What are functions?
/*
Functions(and Procedures) are the building blocks of programs. They are small sections of code that are used to perform a particular
task, and are used for two main reasons-
1. They avoid the repetion of code
2. The second reason is that with the functions, we can break down the code into smaller modules that gives code a logical structure
*/
//To create a function in PHP
//Just type
function functionName(parameters(if any)){}

//Some functions-
//1. Function to create the header of a page
function createPageHeader($title)
{
    echo"<!DOCTYPE html>";
    echo"<html>";
    echo"<head>";
    echo"<meta charset='UTF-8'>";
    //$stylesheetFile = _FILE_CSS_DEFAULT;
    if(isset($_GET["mode"]))
    {
        if($_GET["mode"]=="print")
        {
            $stylesheetFile= _FILE_CSS_PRINT;
        }
        else
        {
            if($_GET["mode"]=="accessibility")
            {
                $stylesheetFile = _FILE_CSS_ACCESSIBILITY;
            }
        }
    }
    ?>
    <link rel="stylesheet", type="text/css", href="<?php echo _DEFAULT_STYLESHEET; ?>">
    <?php
    echo"<title>$title</title>";
    echo"</head>";
    echo"<body>";
    ?>
}

//2.To create a footer
function createPageFooter()
{
    $date = new datetime("now");
    echo"<br>";
    echo"Copyright Collège LaSalle ".date("Y");
    echo"</body>";
    echo"</html>";
}

//3.To create a navigation bar
function createNavigationMenu()
{
    echo"<br>";
    echo"<a href='index.php'>Home Page</a>";
    echo"<br>";
    echo"<a href='about.php'>About Us</a>";
    echo"<br>";
    echo"<a href='Products.php'>Products</a>";
    echo"</br>";
}
//4. To create a list from array
function listFromArray($array)
{
    echo"<ol>";
    foreach($array as $val)
    {
        echo"<li>val</li>";
    }
    echo"</ol>";
}

//5. To create a dropdown
function createDropdown($array)
{
    echo"<select>";
    for($position=0;$position<count($array);$position++)
    {
        echo"<option>$array[$position]</option>";
    }
    echo"</select>";
}

//===================================================================================================================================
//Validation in PHP
//1.To check if a type of variable is that of a particular type
//i.e., using is_integer, is_int, is_iterable, is_array, is_subclass_of, is_bool, is_set etc
//Usage->
if(is_numeric($numericVariable)) {//Do something}

//2. To check position
define("_PART_NO_SYMBOL", "#");
$oldPartNumber2 = "C# for dummies #CSHARP72";
$oldPartNumber = "part #1375";
echo "Position of the letter 'T' is ".strpos($test, "t");
echo "Position of the character '#' is ".strpos($oldPartNumber, _PART_NO_SYMBOL);
echo "City name starting from the character 3 is:" . substr($test, 3);
echo "Number following the '#' is ". substr($oldPartNumber, strpos($oldPartNumber, _PART_NO_SYMBOL)+1);

echo "Number following the second '#' is ". substr($oldPartNumber2, strrpos($oldPartNumber2, _PART_NO_SYMBOL)+1);

//3.Adding numbers and checking if they both are numeric
function addNumbers($number1,$number2)
{
    //if both variables are numeric,Add the numbers and then return the result
    if(is_numeric($number1) && is_numeric($number2))
    {
        $result = $number1+$number2;
        return $result;
    }
    //else, return false;
    else{
        return false;
    }
}

//Call the function and display either the result or an error message
$resultFunction = addNumbers(77.88, 66);
if($resultFunction == false){
    echo "You must enter two numbers.";
}
else{
    echo "The addition of the two numbers is ".$resultFunction;
}

//4.DateTime Validation
if($stringDateInTime>$todayDate)
{
    echo"The date can't be in the future.";
}
else if($result == false){
    echo "Please enter a valid date";
}
else
{
    //create a dateTime object with the validated string
    $dateTimeObject = new DateTime($stringDate);
}

//5. Exploding a String [Split a string by a string]
Returns an array of string, each of which is a substring formed by splitting it on boundries of splitting on boundries
formed by the string delimiter
explode ( string $delimiter , string $string [, int $limit = PHP_INT_MAX ] ) : array

// Example 1
$pizza  = "piece1 piece2 piece3 piece4 piece5 piece6";
$pieces = explode(" ", $pizza);
echo $pieces[0]; // returns piece1
echo $pieces[1]; // returns piece2

//6. Imploding(Joining) a array [Join array elements with a string]
implode ( string $glue , array $pieces ) : string
implode ( array $pieces ) : string

//Example 1
$array = array('lastname', 'email', 'phone');
$comma_separated = implode(",", $array);

echo $comma_separated; // lastname,email,phone

// Empty string when using an empty array:
var_dump(implode('hello', array())); // string(0) ""

//6.To know the time to execute a function
$startDateTime = new DateTime("now");
for($i=0; $i<1000;$i++)
{
    echo $i;
}
$endDateTime = new DateTime("now");
$timeTaken = $startDateTime ->diff($endDateTime);
echo $timeTaken->format("It took %s.%F seconds to execute.");

//===================================================================================================================================
/*
Errors in PHP
In PHP we have 4 categories of errors,
RunTime Errors, RunTime Exceptions, Compilation Errors and the logical errors.
In RT errors, you can't continue but in RT exceptions you can.
ONLY EXCEPTIONS ARE CALLED BY tryCatch and not the errors
It changes from one PHP version to the other.
*/ 

//Try, catch and finally
function getMessage()
{
    echo"There is an error. Please resolve it before continuing.";
}
try
{
    if((9/0)<9)
    {
        echo"My maths is not good.";
    }
}
catch(Exception $exception)
{
    echo"An error occured ".$exception->getMessage();
}
finally
{
    fclose();
    //Always close the files, because if you don't, it remains in the process
    //So if you try to edit the file somewhere, then it can show that process already going on somewhere else.
}

//Creating error logs in php
define("LOG_FILENAME", "Logs.txt");
function manageError($errorCode,$errorFile, $errorMessage, $errorLine)
{
    echo "An error occured:<br>";
    echo "ErrorCode: " . $errorCode ."<br>";
    echo "Error message: " . $errorMessage."<br>";
    echo "Filename: " . $errorFile."<br>";
    echo "Line number: " . $errorLine."<br>";
    //save the infos in the log.txt file
    // $myfile = fopen("Logs.txt", "w");
    file_put_contents(LOG_FILENAME,"an error occured at ..y/m/d h:m:s");
    file_put_contents(LOG_FILENAME,"ErrorCode: " .$errorCode."\r\n", FILE_APPEND);
    file_put_contents(LOG_FILENAME,"Error message: " .$errorMessage."\r\n", FILE_APPEND);
    file_put_contents(LOG_FILENAME,"Filename: " .$errorFile."\r\n", FILE_APPEND);
    file_put_contents(LOG_FILENAME,"Line number: " .$errorLine."\r\n", FILE_APPEND);
    
    die(" An error occured");
    
    //saving all these errors in the file is to be done in the project
}

function manageException($exception)
{
    echo "An exception occured: <br>";
    echo "Exception code: " . $exception->getCode();
    echo "Exception message: " . $exception->getMessage();
    echo "Exception file name: " . $exception->getFile();
    echo "Exception line number: " . $exception->getNumber();
    die("an exception occured");
}

set_error_handler("manageError");
set_exception_handler("manageException");

$fname="Gurbaj";
$lname="Singh";
//generate error
echo 1/0;
    
//generate exception
$exception=new DateTime("2001-88-55");

$myfile = fopen("Logs.txt", "r") or die("Unable to open file!");
echo fread($myfile,filesize("Logs.txt"));
fclose($myfile);
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        echo 1/0;
        echo $exception;
        ?>
    </body>
</html>


?>

//$_SERVER imp!
$_SERVER["USER_AGENT"]