<!-- Gurbaj Singh 
1911150
March 2 [Created the page with the header, footer and the navigation bar]
March 10[Created the createPurchasesPage function for this page]
-->

<?php
include"PHP_Functions/FunctionsFile_1.php";
$_GET["mode"]="purchase";
createPageHeader("Form");
createNavbar();
createPurchasesPage();
createPageFooter();
?> 